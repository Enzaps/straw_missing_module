odoo.define('pos_network_printer_eight.CashButton', function(require) {
    'use strict';

    const PosComponent = require('point_of_sale.PosComponent');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const { useListener } = require('web.custom_hooks');
    const Registries = require('point_of_sale.Registries');
    const PaymentScreen = require('point_of_sale.PaymentScreen');
    class CashButton extends PaymentScreen {
        constructor() {
            debugger;
            super(...arguments);
            useListener('click', this.onClick);
        }
        async onClick() {
            const order = this.env.pos.get_order();
            if (order.get_orderlines().length > 0) {
            var payment_method = {
                "id": 1,
                "name": "Cash",
                "is_cash_count": true,
                "use_payment_terminal": false
            }
            this.currentOrder.add_paymentline(payment_method)
            this._finalizeValidation()
            } else {
                await this.showPopup('ErrorPopup', {
                    title: this.env._t('Nothing to Print'),
                    body: this.env._t('There are no order lines'),
                });
            }
        }
    }
    CashButton.template = 'CashButton';

    ProductScreen.addControlButton({
        component: CashButton,
        condition: function() {
            return true;
        },
        position: ['before', 'SetPricelistButton'],
    });

    Registries.Component.add(CashButton);

    return CashButton;
});
