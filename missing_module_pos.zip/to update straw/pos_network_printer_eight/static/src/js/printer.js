odoo.define('pos_network_printer_eight.Printer', function (require) {
    'use strict';
    var core = require('web.core');
//    var codepage = require('codepage');
    var Registries = require('point_of_sale.Registries');
//    var mixins = require('point_of_sale.Printer');
    var mixins = require('pos_network_printer_eight.PrinterEzp');
//    var EscPos =require('point_of_sale.xml-parser');
//    var ReceiptScreen = require('point_of_sale.ReceiptScreen');
    var ReceiptScreen = require('point_of_sale.ReceiptScreen');
    var ProductScreen = require('point_of_sale.ProductScreen');
    const {_t} = require('web.core');
    var QWeb = core.qweb;
    var OrderReceipt = require('point_of_sale.OrderReceipt');
    const {useRef, useContext} = owl.hooks;
//    var NetPrinter = require('pos_network_printer.Printer');


    var Printer = core.Class.extend(mixins.PrinterMixin, {

        init: function () {
            mixins.PrinterMixin.init.call(this, arguments);
            this.widget = this;
        },


        jspmWSStatus: function () {
            if (JSPM.JSPrintManager.websocket_status == JSPM.WSStatus.Open)
                return true;
            else if (JSPM.JSPrintManager.websocket_status == JSPM.WSStatus.Closed) {
                console.warn('JSPrintManager (JSPM) is not installed or not running! Download JSPM Client App from https://neodynamic.com/downloads/jspm');
                return false;
            }
            else if (JSPM.JSPrintManager.websocket_status == JSPM.WSStatus.Blocked) {
                alert('JSPM has blocked this website!');
                return false;
            }
        },

        print_offline: function (widget, receipt, printer) {
            var self = this;
            var order = widget.env.pos.get_order();
            var receipt_data = {
                "uid": order.uid,
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "receipt": receipt
            };
            var receipt_db = widget.env.pos.db.load('receipt', []);
            receipt_db.push(receipt_data);
            widget.env.pos.db.save('receipt', receipt_db);

            var data = {
                "jsonrpc": "2.0",
                "params": receipt_data
            }
            $.ajax({
                dataType: 'json',
                headers: {
                    "content-type": "application/json",
                    "cache-control": "no-cache",
                },
                url: '/print-network-xmlreceipt',
                type: 'POST',
                proccessData: false,
                data: JSON.stringify(data),
                success: function (res) {
                    var data = JSON.parse(res.result);
                    if (data.error == 0) {
                        self.remove_printed_order(widget, data.uid);
                    }
                    if (data.error == 1) {
                        widget.pos.set({printer: {state: 'disconnected'}, spooler: {state: 'connecting'}});
                    }
                }
            });
        },
        print_online: function (widget, printer) {
            var self = this;
            var order = widget.env.pos.get_order();
            var queue_print_data = {
                "printer_name": printer.printer_name,
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "connector_id": printer.connector_id[0],
                "receipt": receipt,
                "token": self.get_connector_token(widget, printer),
            }
            widget.env.pos.rpc({
                model: 'queue.print',
                method: 'create',
                args: [queue_print_data]
            }).then(function (result) {
                console.log('new queue created ' + 1);
            });
        },
        print_jspm: function (widget, ticketImage, printer) {
            var self = this;
            var escpos = Neodynamic.JSESCPOSBuilder;
            var doc = new escpos.Document();

            ticketImage.then(function (b64img) {
                escpos.ESCPOSImage.load("data:image/png;base64," + b64img).then(img => {
                    var escposCommands = doc
                        .image(img)
                        .feed(5)
                        .cut()
                        .generateUInt8Array();

                    if (self.jspmWSStatus()) {
                        var myPrinter = new JSPM.NetworkPrinter(parseInt(printer.printer_port), printer.printer_ip, printer.printer_name);
                        var cpj = new JSPM.ClientPrintJob();
                        cpj.clientPrinter = myPrinter;
                        cpj.binaryPrinterCommands = escposCommands;
                        cpj.sendToClient();
                    }
                })

            });

        },
        remove_printed_order: function (widget, uid) {
            var receipt_db = widget.env.pos.db.load('receipt', []);
            var printed_receipt = receipt_db.pop();
            if (printed_receipt.uid != uid) {
                receipt.push(printed_receipt);
            }
            widget.env.pos.db.save('receipt', receipt_db);
        },
        get_connector_token: function (widget, printer) {
            var connector = _.filter(widget.env.pos.printer_connectors, function (line) {
                return line.id == printer.connector_id[0]
            });
            return connector[0].token;
        },
        print_offline_kot: function (widget, receipt, printer) {
            var self = this;
            var order = widget.pos.get_order();
            var receipt_data = {
                "uid": order.uid,
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "receipt": receipt
            };
            var receipt_db = widget.pos.db.load('receipt', []);
            receipt_db.push(receipt_data);
            widget.pos.db.save('receipt', receipt_db);

            var data = {
                "jsonrpc": "2.0",
                "params": receipt_data
            }
            $.ajax({
                dataType: 'json',
                headers: {
                    "content-type": "application/json",
                    "cache-control": "no-cache",
                },
                url: '/print-network-xmlreceipt',
                type: 'POST',
                proccessData: false,
                data: JSON.stringify(data),
                success: function (res) {
                    var data = JSON.parse(res.result);
                    if (data.error == 0) {
                        self.remove_printed_order_kot(widget, data.uid);
                    }
                    if (data.error == 1) {
                        widget.pos.set({printer: {state: 'disconnected'}, spooler: {state: 'connecting'}});
                    }
                }
            });
        },
        print_online_kot: function (changes, printer) {
            var self = this;
            var order = widget.pos.get_order();
            var queue_print_data = {
                // "uid": order.uid,
                "printer_name": printer.name,
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "connector_id": printer.connector_id[0],
                "receipt": receipt,
                "token": self.get_connector_token_kot(widget, printer),
            }
            widget.pos.rpc({
                model: 'queue.print',
                method: 'create',
                args: [queue_print_data]
            }).then(function (result) {
                console.log('new queue created ' + 1);
            });
        },
        print_jspm_kot: function (changes, printer) {
            var self = this;
            var escpos = Neodynamic.JSESCPOSBuilder;
            var doc = new escpos.Document();
            var table_list = [];
            var table_list_price = [];
            table_list.push(changes.name.split('-')[2])
            table_list_price.push(changes.name.split('-')[2])
            for (var i = 0; i < changes.new.length; i++) {
                for(var s=0;s<changes.new[i].name.split('-').length;s++){
                if(s==0){
                if (changes.new[i].note != ""){
                table_list.push(changes.new[i].name.split('-')[s] +'('+changes.new[i].note+')');
                table_list_price.push(changes.new[i].qty+'  '+'SR:'+changes.new[i].price);
                }
                else{
                table_list.push(changes.new[i].name.split('-')[s]);
                table_list_price.push(changes.new[i].qty+'  '+'SR:'+changes.new[i].price);

                }
                }
                else{
               table_list.push(changes.new[i].ar_name);
               table_list_price.push(changes.new[i].ar_name);
               }
               }
               }
            var myCanvas = document.createElement("canvas");
            var context = myCanvas.getContext("2d");
            myCanvas.width = 800;
            myCanvas.height = table_list.length*34;
            context.fillStyle = "#ffffff";
            context.fillRect(0, 0, myCanvas.width, myCanvas.height);
            var avatar = new Image();
            avatar.setAttribute('crossOrigin', 'anonymous');
            var avatarWidth = 100;
            context.font = '30px Arial';
            context.fillStyle = '#66c';
             var test_len = 1;
             var price_test =0;
             for (var i = 0; i < table_list.length; i++) {

                 if(i==0){
                 test_len =1

                 }
                 else{
                 test_len+=1
                 }
                 context.font = '22px Arial';
                 context.fillStyle = '#66c';
                 if(i == 0){
                 context.font = '40px Arial';
                 context.fillStyle = '#66c';
                 context.fillText(table_list[i], 250,test_len*34);
                 }
                 else{
                 if(test_len != 1 && price_test == 0){
                 context.fillText(table_list[i], 20,test_len*34);
                 context.fillText(table_list_price[i], 480,test_len*34);
                 price_test +=1
                 }
                 else{
                 context.font = '30px Arial';
                 context.fillText(table_list[i], 20,test_len*34);
                 price_test = 0
                 }
                 }

                 }
            var img = document.createElement("img");
            img.src = myCanvas.toDataURL()
            var img_mou = img.src
            escpos.ESCPOSImage.load(img_mou).then(img => {
            var escposCommands = doc
                .image(img)
                .feed(5)
                .cut()
                .generateUInt8Array();

                if (self.jspmWSStatus()) {
                    var myPrinter = new JSPM.NetworkPrinter(parseInt(printer.printer_port), printer.printer_ip, printer.printer_name);
                    var cpj = new JSPM.ClientPrintJob();
                    cpj.clientPrinter = myPrinter;
                    cpj.binaryPrinterCommands = escposCommands;
                    cpj.sendToClient();
                }
                })
        },
        print_websocket: function (widget, receipt, printer) {
            var self = this;
            var receipt_data = JSON.stringify({
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "xmlreceipt": receipt,
                "origin": window.location.origin,
            });
            var client_app_ip = widget.env.pos.config.client_app_ip;
            var client_app_port = widget.env.pos.config.client_app_port;
            var url = "http://"+client_app_ip+":"+client_app_port;
            console.log('print using websocket '+url);
            var app_headers = new Headers();
            app_headers.append("Access-Control-Allow-Origin", "*");
            app_headers.append("Content-Type", "application/json");
            var requestOptions = {
                method: 'POST',
                headers: app_headers,
                mode: 'no-cors',
                body: receipt_data,
                redirect: 'follow'
            };
            fetch(url, requestOptions)
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.log('error', error));
        },
        print_websocket_kot: function (widget, receipt, printer) {
            var self = this;
            console.log('print using web socket');
            console.log(widget);
            var receipt_data = JSON.stringify({
                "printer_ip": printer.printer_ip,
                "printer_port": printer.printer_port,
                "xmlreceipt": receipt,
                "origin": window.location.origin,
            });
            var client_app_ip = widget.pos.config.client_app_ip;
            var client_app_port = widget.pos.config.client_app_port;
            var url = "http://"+client_app_ip+":"+client_app_port;
            var app_headers = new Headers();
            app_headers.append("Access-Control-Allow-Origin", "*");
            app_headers.append("Content-Type", "application/json");

            var requestOptions = {
                method: 'POST',
                headers: app_headers,
                mode: 'no-cors',
                body: receipt_data,
                redirect: 'follow'
            };

            fetch(url, requestOptions)
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.log('error', error));
        },
        remove_printed_order_kot: function (widget, uid) {
            var receipt_db = widget.pos.db.load('receipt', []);
            var printed_receipt = receipt_db.pop();
            if (printed_receipt.uid != uid) {
                receipt.push(printed_receipt);
            }
            widget.pos.db.save('receipt', receipt_db);
        },
        get_connector_token_kot: function (widget, printer) {
            var connector = _.filter(widget.pos.printer_connectors, function (line) {
                return line.id == printer.connector_id[0]
            });
            return connector[0].token;
        },

    });

    Registries.Component.add(Printer);

    return Printer;
});
