odoo.define('pos_network_printer_eight.Multiprint', function (require) {
    "use strict";

    var models = require('point_of_sale.models');
    var core = require('web.core');
    var QWeb = core.qweb;
    var _t = core._t;
    var NetPrinter = require('pos_network_printer_eight.Printer');
//    var NetPrinter = require('pos_network_printer_eight.PrinterEzp');
    var current_printer = new NetPrinter();
     const ReceiptScreen = require('point_of_sale.ReceiptScreen');
    var _super_orderline = models.Orderline.prototype
    models.load_fields('product.product', 'ar_name');
    models.Orderline = models.Orderline.extend({
        initialize: function(session, attributes){
            var self = this;
            models.load_fields('pos.order.line', ['new_field']);
            _super_orderline.initialize.apply(this, arguments);
        }
    });
    models.Order = models.Order.extend({
      build_line_resume: function(){
        var resume = {};
        this.orderlines.each(function(line){
            if (line.mp_skip) {
                return;
            }
            var line_hash = line.get_line_diff_hash();
            var ar_name = line.product.ar_name;
            var price = line.price;
            var qty  = Number(line.get_quantity());
            var note = line.get_note();
            var product_id = line.get_product().id;

            if (typeof resume[line_hash] === 'undefined') {
                resume[line_hash] = {
                    qty: qty,
                    note: note,
                    product_id: product_id,
                    ar_name: ar_name,
                    price: price,
                    product_name_wrapped: line.generate_wrapped_product_name(),
                };
            } else {
                resume[line_hash].qty += qty;
            }

        });
        return resume;
    },
    saveChanges: function(){
        this.saved_resume = this.build_line_resume();
        this.orderlines.each(function(line){
            line.set_dirty(false);
        });
        this.trigger('change',this);
    },
        computeChanges: function(categories){
        var current_res = this.build_line_resume();
        var old_res     = this.saved_resume || {};
        var json        = this.export_as_JSON();
        var add = [];
        var rem = [];
        var line_hash;

        for ( line_hash in current_res) {
            var curr = current_res[line_hash];
            var old  = {};
            var found = false;
            for(var id in old_res) {
                if(old_res[id].product_id === curr.product_id){
                    found = true;
                    old = old_res[id];
                    break;
                }
            }

            if (!found) {
                 var product_name =curr.product_name_wrapped[0].split('(')[0]
                 var ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name;
                 if(curr.product_name_wrapped[0].split('(').length == 2){
                 ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name+'||'+curr.product_name_wrapped[0].split('(')[1].replace(')','')
                 }

                if(this.pos.db.get_product_by_id(curr.product_id).ar_name){
                    product_name +='-'+this.pos.db.get_product_by_id(curr.product_id).ar_name
                }
                add.push({
                    'id':       curr.product_id,
                    'name': product_name,
                    'name_wrapped': curr.product_name_wrapped,
                    'note':     curr.note,
                    'ar_name':    ar_name,
                    'price':   curr.price,
                    'qty': curr.qty,
                });
            } else if (old.qty < curr.qty) {
                 var ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name;
                 if(curr.product_name_wrapped[0].split('(').length == 2){
                 ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name+'||'+curr.product_name_wrapped[0].split('(')[1].replace(')','')
                 }
                var qty = curr.qty - old.qty
                var qty_new = qty+'  SR:'+curr.price
                var product_name =curr.product_name_wrapped[0].split('(')[0];
                if(this.pos.db.get_product_by_id(curr.product_id).ar_name){
                    product_name +='-'+this.pos.db.get_product_by_id(curr.product_id).ar_name
                }
                add.push({
                    'id':       curr.product_id,
                    'name':  product_name,
                    'name_wrapped': curr.product_name_wrapped,
                    'note':     curr.note,
                     'ar_name':  ar_name,
                     'price':   curr.price,
                    'qty':     qty_new,
                });
            } else if (old.qty > curr.qty) {
                 var qty = old.qty - curr.qty
                var qty_new = qty+'  SR:'+old.amount_total
                var ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name;
                 if(curr.product_name_wrapped[0].split('(').length == 2){
                 ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name+'||'+curr.product_name_wrapped[0].split('(')[1].replace(')','')
                 }
                 var product_name =curr.product_name_wrapped[0].split('(')[0];

                if(this.pos.db.get_product_by_id(curr.product_id).ar_name){
                   product_name +='-'+this.pos.db.get_product_by_id(curr.product_id).ar_name
                }
                rem.push({
                    'id':       curr.product_id,
                    'name':product_name,
                    'name_wrapped': curr.product_name_wrapped,
                    'note':     curr.note,
                    'ar_name':   ar_name,
                    'qty':     qty_new,
                    'price':   curr.price,
                });
            }
        }

        for (line_hash in old_res) {
            var found = false;
            for(var id in current_res) {
                if(current_res[id].product_id === old_res[line_hash].product_id)
                    found = true;
            }
            if (!found) {
                 var ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name;
                 if(curr.product_name_wrapped[0].split('(').length == 2){
                 ar_name = this.pos.db.get_product_by_id(curr.product_id).ar_name+'||'+curr.product_name_wrapped[0].split('(')[1].replace(')','')
                 }
                var old = old_res[line_hash];
                var qty = old.qty
                var qty_new =qty+'  SR:'+json.amount_total
                var product_name =curr.product_name_wrapped[0].split('(')[0];
                if(this.pos.db.get_product_by_id(old.product_id).ar_name){
                   product_name +='-'+this.pos.db.get_product_by_id(old.product_id).ar_name
                }
                rem.push({
                    'id':       old.product_id,
                    'name': product_name,
                    'name_wrapped': old.product_name_wrapped,
                    'note':     old.note,
                    'ar_name': ar_name,
                    'qty':     qty_new,
                    'price':  old.price,
                });
            }
        }

        if(categories && categories.length > 0){
            // filter the added and removed orders to only contains
            // products that belong to one of the categories supplied as a parameter

            var self = this;

            var _add = [];
            var _rem = [];

            for(var i = 0; i < add.length; i++){
                if(self.pos.db.is_product_in_category(categories,add[i].id)){
                    _add.push(add[i]);
                }
            }
            add = _add;

            for(var i = 0; i < rem.length; i++){
                if(self.pos.db.is_product_in_category(categories,rem[i].id)){
                    _rem.push(rem[i]);
                }
            }
            rem = _rem;
        }

        var d = new Date();
        var hours   = '' + d.getHours();
            hours   = hours.length < 2 ? ('0' + hours) : hours;
        var minutes = '' + d.getMinutes();
            minutes = minutes.length < 2 ? ('0' + minutes) : minutes;
        var date_complete = d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()+'|'+d.getHours()+':'+d.getMinutes();

        return {
            'new': add,
            'cancelled': rem,
            'table': json.table || false,
            'floor': json.floor || false,
            'name': json.name  || 'unknown order',
            'time': {
                'hours':   hours,
                'minutes': minutes,
                'date_complete': date_complete,
            },
        };

    },


        printChanges: async function () {
            var self = this;
            self.arabic_data =[];
            var printers = this.pos.printers;
            let isPrintSuccessful = true;
            for (var i = 0; i < printers.length; i++) {
                var changes = this.computeChanges(printers[i].config.product_categories_ids);
                if (changes['new'].length > 0 || changes['cancelled'].length > 0) {
                    var receipt = QWeb.render('OrderChangeReceiptCustom', {changes: changes, widget: this});
                    if (printers[i].config.printer_type == "nt_printer") {
                        if (self.pos.config.printing_mode == 'offline') {
                            current_printer.print_offline_kot(self, receipt, printers[i].config);
                        }
                        if (self.pos.config.printing_mode == 'online') {
                            if (self.pos.config.connector == 'jspm') {
                                current_printer.print_jspm_kot(changes, printers[i].config);
                            }
                            if (self.pos.config.connector == 'websocket') {
                                current_printer.print_websocket_kot(self, receipt, printers[i].config);
                            }
                            if (self.pos.config.connector == 'printc') {
                                current_printer.print_online_kot(changes, printers[i].config, receipt, self);
                            }
                        }
                    } else {
                        const result = await printers[i].print_receipt(receipt);
                        if (!result.successful) {
                            isPrintSuccessful = false;
                        }
                    }
                }
            }
            return isPrintSuccessful;
        }

    });

});
