import { BufferBuilder } from './buffer-builder';
export declare class XMLParser {
    parser(xml: string): BufferBuilder;
    private compile;
    private adapter;
}
