================================
POS BASIC SYNCHRONIZATION MODULE
================================

1) Install This Module And Setup Ur main server details under Configuration File
   POS => Configuration => Synch Configuration Menu
   example :
           Server Url =http://xxxxxxxxxxx:8069
           Database Name = database name(ur main server)
           User Name  = login user(admin)
           Password   = login password(admin)
           active = True


